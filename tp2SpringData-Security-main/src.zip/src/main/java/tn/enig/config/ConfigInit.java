package tn.enig.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class ConfigInit extends AbstractSecurityWebApplicationInitializer {
}
